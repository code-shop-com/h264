/*******************************************************************************
 mod_h264_streaming.c

 mod_h264_streaming - An AOLServer module for streaming Quicktime/MPEG4 files.

 Copyright (C) 2009 CodeShop B.V.

 Licensing
 The Streaming Module is licened under a Creative Commons License. It
 allows you to use, modify and redistribute the module, but only for
 *noncommercial* purposes. For corporate use, please apply for a
 commercial license.

 Creative Commons License:
 http://creativecommons.org/licenses/by-nc-sa/3.0/

 Commercial License for H264 Streaming Module:
 http://h264.code-shop.com/trac/wiki/Mod-H264-Streaming-License-Version2

 Commercial License for Smooth Streaming Module:
 http://smoothstreaming.code-shop.com/trac/wiki/Mod-Smooth-Streaming-License
******************************************************************************/ 

static const char *RCSID = "@(#) $Header: mod_h264_streaming.c,v 1.1 2009/12/02 DAG Exp $, compiled: " __DATE__ " " __TIME__;

#include "ns.h"
#include "mp4_io.h"
#include "mp4_process.h"
#include "moov.h"
#include "output_bucket.h"
#include "output_mp4.h"

/*
 * The Ns_ModuleVersion variable is required.
 */
int Ns_ModuleVersion = 1;


/*
 * Private functions
 */
int
Ns_ModuleInit(char *hServer, char *hModule);

static int
h264Init(Tcl_Interp *interp, void *context);

/*
 * h264open $filename $start ($end) - return a handle; $end is optional
 * h264length $handle - returns total number of bytes for Content-Length
 * h264read $handle - get a chunk of data; won't return empty before eof
 * h264close $handle - destroy, free memory etc
 */
static int
h264open(ClientData context, Tcl_Interp *interp, int argc, Tcl_Obj *CONST argv[]);
static int
h264length(ClientData context, Tcl_Interp *interp, int argc, Tcl_Obj *CONST argv[]);
static int
h264read(ClientData context, Tcl_Interp *interp, int argc, Tcl_Obj *CONST argv[]);
static int
h264eof(ClientData context, Tcl_Interp *interp, int argc, Tcl_Obj *CONST argv[]);
static int
h264close(ClientData context, Tcl_Interp *interp, int argc, Tcl_Obj *CONST argv[]);



/*
 *----------------------------------------------------------------------
 *
 * Ns_ModuleInit --
 *
 *      This is the nsexample module's entry point.  AOLserver runs
 *      this function right after the module is loaded.  It is used to
 *      read configuration data, initialize data structures, kick off
 *      the Tcl initialization function (if any), and do other things
 *      at startup.
 *
 * Results:
 *	NS_OK or NS_ERROR
 *
 * Side effects:
 *	Module loads and initializes itself.
 *
 *----------------------------------------------------------------------
 */
 
int
Ns_ModuleInit(char *hServer, char *hModule)
{
  return (Ns_TclInitInterps(hServer, h264Init, NULL));
}


/*
 *----------------------------------------------------------------------
 *
 * h264Init --
 *
 *      Register new commands with the Tcl interpreter.
 *
 * Results:
 *	NS_OK or NS_ERROR
 *
 * Side effects:
 *	A C function is registered with the Tcl interpreter.
 *
 *----------------------------------------------------------------------
 */
 
static int
h264Init(Tcl_Interp *interp, void *context)
{
  Tcl_CreateObjCommand(interp, "h264open", h264open, NULL, NULL);
  Tcl_CreateObjCommand(interp, "h264length", h264length, NULL, NULL);
  Tcl_CreateObjCommand(interp, "h264read", h264read, NULL, NULL);
  Tcl_CreateObjCommand(interp, "h264eof", h264eof, NULL, NULL);
  Tcl_CreateObjCommand(interp, "h264close", h264close, NULL, NULL);

  return NS_OK;
}

/*
 *----------------------------------------------------------------------
 *
 *
 *----------------------------------------------------------------------
 */

struct h264_t
{
  char filename[512];
  struct mp4_split_options_t* options;
  bucket_t* buckets;
  bucket_t* bucket;
  uint64_t bucket_offset;
  uint64_t offset;
  uint64_t size;
};
typedef struct h264_t h264_t;

h264_t* h264_init()
{
  h264_t* h264 = (h264_t*)ns_malloc(sizeof(h264_t));

  h264->options = mp4_split_options_init();
  h264->buckets = 0;
  h264->bucket_offset = 0;
  h264->offset = 0;
  h264->size = 0;

  return h264;
}

void h264_exit(h264_t* h264)
{
  mp4_split_options_exit(h264->options);
  if(h264->buckets)
  {
    buckets_exit(h264->buckets);
  }
  ns_free(h264);
}

static h264_t* get_handle(Tcl_Interp* interp, int argc, Tcl_Obj *CONST argv[])
{
  if(argc != 2)
  {
    Tcl_WrongNumArgs(interp, 1, argv, "handle");
    return 0;
  }

  int h264_len = 0;
  h264_t* h264 = *(h264_t**)Tcl_GetByteArrayFromObj(argv[1], &h264_len);

  return h264;
}
 
static int
h264open(ClientData context, Tcl_Interp *interp, int argc, Tcl_Obj *CONST argv[])
{
  Ns_Log(Debug, "%s: argc=%i", Tcl_GetStringFromObj(argv[0], NULL), argc);

  if(argc < 2 || argc > 3)
  {
    Tcl_WrongNumArgs(interp, 1, argv, "file [query_parameters]");
    return TCL_ERROR;
  }

  int filename_len = 0;
  char const* filename = Tcl_GetStringFromObj(argv[1], &filename_len);

  int query_len = 0;
  char const* query = NULL;
  if(argc > 2)
  {
    query = Tcl_GetStringFromObj(argv[2], &query_len);
  }

  Ns_Log(Debug, "%s: filename=%s params=%s",
         Tcl_GetStringFromObj(argv[0], NULL), filename, query == NULL ? "" : query);

  h264_t* h264 = h264_init();
  strcpy(h264->filename, filename);

  if(query != NULL)
  {
    if(!mp4_split_options_set(h264->options, query, query_len))
    {
      Ns_Log(Error, "%s: invalid params", Tcl_GetStringFromObj(argv[0], NULL));
      h264_exit(h264);
      return TCL_ERROR;
    }
  }

  int verbose = 0;
  int http_status = mp4_process(filename, get_filesize(filename), verbose, &h264->buckets, h264->options);

  if(http_status != 200)
  {
    h264_exit(h264);
    return TCL_ERROR;
  }

  // get content length
  bucket_t* bucket = h264->buckets;
  do
  {
    h264->size += bucket->size_;
    bucket = bucket->next_;
  } while(bucket != h264->buckets);

  // initialize read bucket
  h264->bucket = h264->buckets;

  Tcl_Obj* obj = Tcl_NewByteArrayObj((unsigned char CONST*)&h264, sizeof(h264_t*));
  Tcl_SetObjResult(interp, obj);

  return TCL_OK;
}

/*
 *----------------------------------------------------------------------
 *
 *
 *----------------------------------------------------------------------
 */
 
static int
h264length(ClientData context, Tcl_Interp *interp, int argc, Tcl_Obj *CONST argv[])
{
  Ns_Log(Debug, "%s", Tcl_GetStringFromObj(argv[0], NULL));

  h264_t* h264 = get_handle(interp, argc, argv);

  if(h264 == NULL)
  {
    return TCL_ERROR;
  }

  Tcl_SetObjResult(interp, Tcl_NewIntObj(h264->size));

  return NS_OK;
}


/*
 *----------------------------------------------------------------------
 *
 *
 *----------------------------------------------------------------------
 */
 
static int
h264read(ClientData context, Tcl_Interp *interp, int argc, Tcl_Obj *CONST argv[])
{
  Ns_Log(Debug, "%s", Tcl_GetStringFromObj(argv[0], NULL));

  h264_t* h264 = get_handle(interp, argc, argv);

  if(h264 == NULL)
  {
    return TCL_ERROR;
  }

  // don't read past EOF
  if(h264->offset == h264->size)
  {
    return TCL_ERROR;
  }

  FILE* fd = fopen(h264->filename, "rb");

  int chunk_size = 64 * 1024;
  int chunk_index = 0;
  unsigned char* dst = ns_malloc(chunk_size);
  for(;;)
  {
    // get current read bucket
    uint64_t left_in_bucket = h264->bucket->size_ - h264->bucket_offset;
    unsigned int left_in_chunk = chunk_size - chunk_index;
    unsigned int size = left_in_bucket > left_in_chunk ? left_in_chunk : left_in_bucket;

    switch(h264->bucket->type_)
    {
      case BUCKET_TYPE_MEMORY:
        memcpy(dst + chunk_index, h264->bucket->buf_ + h264->bucket_offset, size);
        break;
      case BUCKET_TYPE_FILE:
        fseek(fd, h264->bucket->offset_ + h264->bucket_offset, SEEK_SET);
        fread(dst + chunk_index, 1, size, fd);
        break;
    }

    h264->bucket_offset += size;
    chunk_index += size;

    // advance read bucket
    if(h264->bucket_offset == h264->bucket->size_)
    {
      h264->bucket = h264->bucket->next_;
      h264->bucket_offset = 0;

      // check for EOF
      if(h264->bucket == h264->buckets)
      {
        break;
      }
    }

    // chunk full?
    if(chunk_index == chunk_size)
    {
      break;
    }
  }

  fclose(fd);

  h264->offset += chunk_index;

  Tcl_Obj* obj = Tcl_NewByteArrayObj(dst, chunk_index);
  Tcl_SetObjResult(interp, obj);

  ns_free(dst);

  return TCL_OK;
}

static int
h264eof(ClientData context, Tcl_Interp *interp, int argc, Tcl_Obj *CONST argv[])
{
  Ns_Log(Debug, "%s", Tcl_GetStringFromObj(argv[0], NULL));

  h264_t* h264 = get_handle(interp, argc, argv);

  if(h264 == NULL)
  {
    return TCL_ERROR;
  }

  Tcl_SetObjResult(interp, Tcl_NewBooleanObj(h264->offset == h264->size));

  return TCL_OK;
}

/*
 *----------------------------------------------------------------------
 *
 *
 *----------------------------------------------------------------------
 */
 
static int
h264close(ClientData context, Tcl_Interp *interp, int argc, Tcl_Obj *CONST argv[])
{
  Ns_Log(Debug, "%s", Tcl_GetStringFromObj(argv[0], NULL));

  h264_t* h264 = get_handle(interp, argc, argv);

  if(h264 == NULL)
  {
    return TCL_ERROR;
  }

  h264_exit(h264);

  return NS_OK;
}

// End Of File

